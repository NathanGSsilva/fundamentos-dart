void main( List<String> args ) {

List<int> listaNumeros = [1,2,3,4];

List<String> listaTextos = ["fulano","delcrano","ciclano"];

print(listaNumeros[1]);
print(listaTextos[1]);

var listadenumeros = [1,2,3];

for(var i = 0; i <= 2; i++){

print(listadenumeros[i]);
}

List<int> listaSemDados = [];

print(listaSemDados[1]);

var listaSemDadosInferenia = [];

print(listaSemDadosInferenia[1]);

var listaSemDadosInfereniaGenerica = <int>[];

print(listaSemDadosInfereniaGenerica[1]);

}