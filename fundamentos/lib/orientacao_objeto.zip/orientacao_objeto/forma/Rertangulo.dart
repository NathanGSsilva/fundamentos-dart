import 'Forma.dart';
import 'enum.dart';

class Retangulo extends Forma{
  double comprimento = 0;
  double altura = 0;

  Retangulo( this.comprimento, this.altura) : super(tpForma.Retangulo);

  @override
  double calculaArea(){
    return comprimento * altura;
  }
}